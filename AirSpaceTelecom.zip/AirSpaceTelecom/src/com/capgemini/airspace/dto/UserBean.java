package com.capgemini.airspace.dto;

/**
 * Author 		: HAHA 
 * Class Name 	: UserBean 
 * Package 		: com.capgemini.airspace.bean 
 * Date 		: 04/12/17
 */
public class UserBean {

	private String customerName;

	private String userName;

	private String mobile_number;

	private String password;

	/**
	 * Default constructor
	 **/
	public UserBean() {
		super();
	}

	/**
	 * Parametrized constructor
	 **/
	public UserBean(String customerName, String userName, String mobile_number,
			String password) {
		super();
		this.customerName = customerName;
		this.userName = userName;
		this.mobile_number = mobile_number;
		this.password = password;
	}

	/**
	 * Getters and Setters
	 **/
	public String getCustomerName() {
		return customerName;
	}

	public void setCustomerName(String customerName) {
		this.customerName = customerName;
	}

	public String getUserName() {
		return userName;
	}

	public void setUserName(String userName) {
		this.userName = userName;
	}

	public String getMobile_number() {
		return mobile_number;
	}

	public void setMobile_number(String mobile_number) {
		this.mobile_number = mobile_number;
	}

	public String getPassword() {
		return password;
	}

	public void setPassword(String password) {
		this.password = password;
	}

	/**
	 * toString() method
	 **/
	@Override
	public String toString() {
		return "UserBean [customerName=" + customerName + ", userName="
				+ userName + ", mobile_number=" + mobile_number + ", password="
				+ password + "]";
	}

}
