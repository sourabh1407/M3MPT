package com.capgemini.airspace.util;

import java.sql.Connection;
import java.sql.SQLException;

import javax.naming.InitialContext;
import javax.naming.NamingException;
import javax.sql.DataSource;

import com.capgemini.airspace.exception.CustomerException;

/**
 * Author 		: HAHA 
 * Class Name 	: DbConnection 
 * Package 		: com.capgemini.airspace.util 
 * Date 		: 04/12/17
 */

public class DbConnection {

	public static Connection getConnection() throws CustomerException {

		Connection conn = null;
		
		//connecting to DataSource
		
		try {
			InitialContext ict = new InitialContext();
			
			DataSource dsrc = (DataSource) ict.lookup("java:/OracleDS");

			conn = dsrc.getConnection();
		}

		catch (SQLException e) {
			throw new CustomerException("SQL Error:" + e.getMessage());
		}

		catch (NamingException e) {
			throw new CustomerException("message from DB/NamingExc:"
					+ e.getMessage());
		}

		return conn;
	}
}
