package com.capgemini.airspace.exception;

/**
 * Author 		: HAHA 
 * Class Name 	: CustomerException 
 * Package 		: com.capgemini.airspace.exception 
 * Date 		: 04/12/17
 */

public class CustomerException extends Exception {
	/**
	 * 
	 */
	private static final long serialVersionUID = 4221581121061133814L;

	public CustomerException(String message) {
		super(message);
	}
}
