package com.capgemini.airspace.controller;

import java.io.IOException;
import java.time.LocalDate;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import com.capgemini.airspace.dto.UserBean;
import com.capgemini.airspace.exception.CustomerException;
import com.capgemini.airspace.service.CustomerService;
import com.capgemini.airspace.service.ICustomerService;

/**
 * Servlet implementation class ProcessUser
 */
@WebServlet({ "/ProcessUser", "/Home", "/Register", "/PayBill", "/Success" })
public class ProcessUser extends HttpServlet {

	private static final long serialVersionUID = 1L;

	protected void doGet(HttpServletRequest request,
			HttpServletResponse response) throws ServletException, IOException {

		//Getting request path
		String path = request.getServletPath();

		HttpSession session = request.getSession(true);

		String target = "";

		if (path.equals("/Home")) {
			target = "views/Register.jsp";
		}

		else if (path.equals("/Register")) {
			ICustomerService service = new CustomerService();
			UserBean user = new UserBean();

			user.setCustomerName(request.getParameter("name"));
			user.setUserName(request.getParameter("userName"));
			user.setMobile_number(request.getParameter("mobileNo"));
			user.setPassword(request.getParameter("password"));
			session.setAttribute("user", user);

			try {
				boolean isInserted = service.insertUser(user);
				if (isInserted) {
					target = "views/CustomerHome.jsp";
				}
			} catch (CustomerException e) {
				request.setAttribute("error", e.getMessage());
				target = "views/Error.jsp";
			}
		}

		else if (path.equals("/PayBill")) {
			target = "views/PayBill.jsp";
		}

		else if (path.equals("/Success")) {
			int amount = Integer.parseInt(request.getParameter("amount"));

			int balanceAmount = 750 - amount;

			request.setAttribute("balance", balanceAmount);

			request.setAttribute("Date", LocalDate.now());

			target = "views/Success.jsp";
		}
		
		//creating dispatcher
		RequestDispatcher dispatcher = request.getRequestDispatcher(target);
		dispatcher.forward(request, response);
	}

	protected void doPost(HttpServletRequest request,
			HttpServletResponse response) throws ServletException, IOException {
		//calling to doGet() method
		doGet(request, response);
	}

}
