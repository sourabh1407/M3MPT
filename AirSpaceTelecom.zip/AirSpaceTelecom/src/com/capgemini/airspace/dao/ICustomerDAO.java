package com.capgemini.airspace.dao;

import com.capgemini.airspace.dto.UserBean;
import com.capgemini.airspace.exception.CustomerException;

/**
 * Author 		: HAHA 
 * Interface 	: ICustomerDAO 
 * Package 		: com.capgemini.airspace.dao 
 * Date 		: 04/12/17
 */
public interface ICustomerDAO {

	public boolean insertCustomer(UserBean user) throws CustomerException;

}
