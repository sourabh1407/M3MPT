package com.capgemini.airspace.dao;

/**
 * Author 		: HAHA 
 * Interface 	: IQueryMapper 
 * Package 		: com.capgemini.airspace.dao 
 * Date 		: 04/12/17
 */
public interface IQueryMapper {

	public static final String INSERTCUSTOMER = "INSERT INTO users VALUES(?,?,?,?)";

}
