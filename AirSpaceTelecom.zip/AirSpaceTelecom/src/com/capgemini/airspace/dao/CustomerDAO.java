package com.capgemini.airspace.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;

import com.capgemini.airspace.dto.UserBean;
import com.capgemini.airspace.exception.CustomerException;
import com.capgemini.airspace.util.DbConnection;

/**
 * Author 		: HAHA
 * Class Name 	: CustomerDAO 
 * Package 		: com.capgemini.airspace.dao
 * Date 		: 04/12/17
 */
public class CustomerDAO implements ICustomerDAO {

	@Override
	public boolean insertCustomer(UserBean user) throws CustomerException {

		boolean isInserted = false;

		try {
			Connection con = DbConnection.getConnection();

			PreparedStatement pst = con
					.prepareStatement(IQueryMapper.INSERTCUSTOMER);

			pst.setString(1, user.getCustomerName());
			pst.setString(2, user.getUserName());
			pst.setString(3, user.getPassword());
			pst.setString(4, user.getMobile_number());

			int records = pst.executeUpdate();

			if (records > 0) {
				isInserted = true;
			}
		} catch (SQLException e) {
			throw new CustomerException(e.getMessage());
		}

		return isInserted;
	}

}
