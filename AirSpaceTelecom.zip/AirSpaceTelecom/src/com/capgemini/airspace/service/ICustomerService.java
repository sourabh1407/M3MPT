package com.capgemini.airspace.service;

import com.capgemini.airspace.dto.UserBean;
import com.capgemini.airspace.exception.CustomerException;

/**
 * Author 		: HAHA 
 * Interface 	: ICustomerService 
 * Package 		: com.capgemini.airspace.service 
 * Date 		: 04/12/17
 */
public interface ICustomerService {
	public boolean insertUser(UserBean userBean) throws CustomerException;
}
