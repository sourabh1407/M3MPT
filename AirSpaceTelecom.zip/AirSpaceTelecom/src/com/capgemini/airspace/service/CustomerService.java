package com.capgemini.airspace.service;

import com.capgemini.airspace.dao.CustomerDAO;
import com.capgemini.airspace.dao.ICustomerDAO;
import com.capgemini.airspace.dto.UserBean;
import com.capgemini.airspace.exception.CustomerException;

/**
 * Author 		: HAHA 
 * Class Name 	: CustomerService 
 * Package 		: com.capgemini.airspace.service 
 * Date 		: 04/12/17
 */
public class CustomerService implements ICustomerService {

	@Override
	public boolean insertUser(UserBean userBean) throws CustomerException {

		ICustomerDAO customerDAO = new CustomerDAO();

		return customerDAO.insertCustomer(userBean);

	}

}
